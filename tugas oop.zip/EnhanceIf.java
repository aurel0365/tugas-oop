// Contoh kodingan untuk enhance if
public class EnhanceIf {
    public static void main(String[] args){
        String name = "Aurelia";
        System.out.println((name.equalsIgnoreCase("Aurelia"))? "benar":"salah");
    }
}

