// Contoh kodingan untuk enhance for
public class EnhanceFor {
    public static void main(String[] args) {
        String[] fruits = {"apel", "pisang", "jeruk", "mangga"};
    
        for (String buah : fruits) {
            System.out.println(buah);
        }
    }
}

