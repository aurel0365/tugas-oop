public class kesalahan {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Masukkan bilangan: ");
        int bilangan = scanner.nextInt();

        String result = (bilangan % 2 == 0) ? "Genap" : "Ganjil";

        System.out.println("Bilangan " + bilangan + " adalah " + result);
    }
